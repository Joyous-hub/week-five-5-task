//Javascript to convert meter to other unit

const unitConverter = document.querySelector("#meter");

unitConverter.addEventListener("input", convert);
function convert(event) {
  let meter = event.target.value;

  document.getElementById("inches").value = meter * 39.2;
  document.getElementById("feet").value = meter * 10;
  document.getElementById("yard").value = meter * 20;
}

//Javascript to convert inches to other unit

const unitConverter1 = document.querySelector("#inches");
unitConverter1.addEventListener("input", convert1);
function convert1(event) {
  let inches = event.target.value;

  document.getElementById("feet").value = inches * 39.2;
  document.getElementById("yard").value = inches * 10;
  document.getElementById("meter").value = inches * 20;
}

//Javascript to convert feet to other unit

const unitConverter2 = document.querySelector("#feet");
unitConverter2.addEventListener("input", convert2);
function convert2(event) {
  let feet = event.target.value;

  document.getElementById("yard").value = feet * 39.2;
  document.getElementById("meter").value = feet * 10;
  document.getElementById("inches").value = feet * 20;
}

//Javascript to convert yard to other unit

const unitConverter3 = document.querySelector("#yard");
unitConverter3.addEventListener("input", convert3);
function convert3(event) {
  let yard = event.target.value;

  document.getElementById("meter").value = yard * 39.2;
  document.getElementById("inches").value = yard * 10;
  document.getElementById("feet").value = yard * 20;
}

//Reset button - clear all

const resetBtn = document.querySelector("button");

resetBtn.addEventListener("click", function () {
  clearAll = document.querySelector("input");

  document.getElementById("meter").value = clearAll;
  document.getElementById("inches").value = clearAll;
  document.getElementById("feet").value = clearAll;
  document.getElementById("yard").value = clearAll;
});
