const firstName = document.getElementById("fname");
const lastName = document.getElementById("lname");
const password = document.getElementById("validate");
const rePassword = document.getElementById("re-validate");

const submitBtn = document.querySelector("#submit");

submitBtn.addEventListener("click", function (e) {
  if (firstName.value === lastName.value) {
    alert("First Name and Last Name must not be the same");
    e.preventDefault();
  }

  if (password.value !== rePassword.value) {
    alert("Password did not match");
    e.preventDefault();
  } else {
    e.submit();
  }
});
